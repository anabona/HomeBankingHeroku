var app = new Vue({
    el: '#app',
    data: {
        client: [],
        url: "",
        account: "",
    },

    created(){
        this.loadData();
    },

methods: {
    addClients() {
        this.postClient();
    },


    loadData() {
        axios.get("/clients") 
        .then(response => {
            console.log(response);
            this.client =  response.data;
            }
        )
    },
        
    

}});