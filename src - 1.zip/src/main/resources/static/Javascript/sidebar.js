

let boton=document.querySelector("#boton");
let sidebar=document.querySelector(".sidebar");
let search=document.querySelector("#bx-search");

boton.onclick = function(){
    sidebar.classList.toggle("active");
}


// search.onclick = function(){
//     sidebar.classList.toggle("active");
// }