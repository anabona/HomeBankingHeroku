package com.mindhub.homebanking.models;

public enum AccountType {
    CAJA_AHORRO,
    CUENTA_CORRIENTE,
}
