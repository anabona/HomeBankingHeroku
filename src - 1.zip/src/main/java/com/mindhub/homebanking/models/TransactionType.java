package com.mindhub.homebanking.models;

public enum TransactionType {
    DEBITO,
    CREDITO,
}
