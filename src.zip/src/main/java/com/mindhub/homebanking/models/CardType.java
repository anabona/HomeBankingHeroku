package com.mindhub.homebanking.models;

public enum CardType {
    CREDIT,
    DEBIT,
}
