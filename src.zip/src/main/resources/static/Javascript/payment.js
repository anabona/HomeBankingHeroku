let payment = new Vue({
  el: '#payment',
  data: {
      montoAPagar:"",
      descripcion:""
  },
  created() {        
  },
  methods: {
      
  }
  
});